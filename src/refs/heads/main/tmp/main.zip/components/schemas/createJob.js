const    createJob = {
    title: String,
    description: String
}

module.exports = createJob;