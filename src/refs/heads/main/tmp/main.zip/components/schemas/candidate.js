const candidate = {
    firstName: String,
    lastName: String,
    email: String
}

module.exports = candidate;