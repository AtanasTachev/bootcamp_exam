const interviewUpdate = {
    jobId: String,
    candidateId: String,
    slot: Number,
}

module.exports = interviewUpdate;