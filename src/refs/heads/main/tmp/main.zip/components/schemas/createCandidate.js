const candidateCreate = {
    firstName: String,
    lastName: String,
    email: String
}

module.exports = candidateCreate;