const candidateUpdate = {
    firstName: String,
    lastName: String,
    email: String
}

module.exports = candidateUpdate;