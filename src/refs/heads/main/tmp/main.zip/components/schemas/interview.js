const interview = {
    _id: String,
    jobId: String,
    candidateId: String,
    slot: Number
}

module.exports = interview;