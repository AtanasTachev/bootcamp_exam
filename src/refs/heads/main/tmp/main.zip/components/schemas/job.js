const job = {
    _id: String,
    title: String,
    description: String
    }
module.exports = job;