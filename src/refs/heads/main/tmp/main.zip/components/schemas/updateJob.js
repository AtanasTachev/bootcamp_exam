const updateJob = {
    title: String,
    description: String
   }

   module.exports = updateJob;